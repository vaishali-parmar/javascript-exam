const taskInput = document.getElementById('taskInput');
const addButton = document.getElementById('addButton');
const taskList = document.getElementById('taskList');

// Load tasks from local storage
let tasks = JSON.parse(localStorage.getItem('tasks')) || [];

// Function to display tasks
function displayTasks() {
    taskList.innerHTML = '';
    tasks.forEach((task, index) => {
        const listItem = document.createElement('li');
        listItem.textContent = task;

        const editButton = document.createElement('button');
        editButton.textContent = 'Edit';
        editButton.addEventListener('click', () => {
            taskInput.value = task;
            tasks[index] = ''; // Clear the old task
            displayTasks();
        });

        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.addEventListener('click', () => {
            tasks.splice(index, 1);
            saveTasks();
            displayTasks();
        });

        const completeButton = document.createElement('button');
        completeButton.textContent = 'Complete';
        completeButton.addEventListener('click', () => {
            listItem.classList.toggle('completed');
        });

        listItem.appendChild(editButton);
        listItem.appendChild(deleteButton);
        listItem.appendChild(completeButton);

        taskList.appendChild(listItem);
    });
}

// Add task
addButton.addEventListener('click', () => {
    const newTask = taskInput.value.trim();
    if (newTask !== '') {
        tasks.push(newTask);
        saveTasks();
        taskInput.value = '';
        displayTasks();
    }
});

// Save tasks to local storage
function saveTasks() {
    localStorage.setItem('tasks', JSON.stringify(tasks));
}

// Load tasks on page load
displayTasks();